"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"

interface User {
  id: string
  nombre: string
  apellidos: string
  codigoPropio: string
}

export default function ReferralLinkGenerator() {
  const [users, setUsers] = useState<User[]>([])
  const [selectedUserId, setSelectedUserId] = useState("")
  const [referralLink, setReferralLink] = useState("")

  useEffect(() => {
    // Cargar la lista de usuarios
    const loadedUsers = JSON.parse(localStorage.getItem("users") || "[]")
    setUsers(loadedUsers)
  }, [])

  useEffect(() => {
    // Generar el enlace de referido basado en el usuario seleccionado
    if (selectedUserId) {
      const selectedUser = users.find((user) => user.id === selectedUserId)
      if (selectedUser) {
        const baseUrl = window.location.origin
        setReferralLink(`${baseUrl}/referral-registration?ref=${selectedUser.codigoPropio}`)
      }
    }
  }, [selectedUserId, users])

  const copyToClipboard = () => {
    navigator.clipboard.writeText(referralLink)
    alert("Enlace copiado al portapapeles")
  }

  return (
    <Card className="bg-[#1f1f1f] mb-8">
      <CardHeader>
        <CardTitle className="text-[#00ffcc]">Generador de Enlaces de Referidos</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <Label htmlFor="userSelect">Selecciona un usuario</Label>
            <select
              id="userSelect"
              value={selectedUserId}
              onChange={(e) => setSelectedUserId(e.target.value)}
              className="w-full p-2 bg-white text-black rounded"
            >
              <option value="">Selecciona un usuario</option>
              {users.map((user) => (
                <option key={user.id} value={user.id}>
                  {user.nombre} {user.apellidos} - {user.codigoPropio}
                </option>
              ))}
            </select>
          </div>
          {selectedUserId && (
            <>
              <div>
                <Label htmlFor="referralCode">Código de referido</Label>
                <Input
                  id="referralCode"
                  value={users.find((user) => user.id === selectedUserId)?.codigoPropio || ""}
                  readOnly
                />
              </div>
              <div>
                <Label htmlFor="referralLink">Enlace de referido</Label>
                <Input id="referralLink" value={referralLink} readOnly />
              </div>
              <Button onClick={copyToClipboard} className="bg-[#00ffcc] text-black hover:bg-[#00e6b8]">
                Copiar Enlace
              </Button>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


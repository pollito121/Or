import { kv } from "@vercel/kv"
import { NextResponse } from "next/server"

export async function GET() {
  const users = (await kv.get("users")) || []
  return NextResponse.json(users)
}

export async function POST(request: Request) {
  const newUser = await request.json()
  const users = (await kv.get("users")) || []
  users.push(newUser)
  await kv.set("users", users)
  return NextResponse.json(newUser, { status: 201 })
}


"use client"

import { useState, useEffect, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

interface UserData {
  nombre: string
  balance: number
  paidBalance: number
  earnings: number
  referralCount: number
}

const EMPRESA_CODE = "ATQDFJ"
const EMPRESA_NAME = "Orbital X"

export default function Dashboard() {
  const [referralCode, setReferralCode] = useState("")
  const [userData, setUserData] = useState<UserData>({
    nombre: "",
    balance: 0,
    paidBalance: 0,
    earnings: 0,
    referralCount: 0,
  })

  const loadUserData = useCallback(async (code: string) => {
    const usersDataResponse = await fetch("/api/usersData")
    const usersData = await usersDataResponse.json()
    const usersResponse = await fetch("/api/users")
    const users = await usersResponse.json()

    if (code === EMPRESA_CODE) {
      const empresaData = usersData[EMPRESA_CODE] || {
        balance: 0,
        paidBalance: 0,
        earnings: 0,
        referralCount: 0,
      }
      setUserData({
        nombre: EMPRESA_NAME,
        ...empresaData,
      })
      return
    }

    const user = users.find((u: any) => u.codigoPropio === code)

    if (user && usersData[code]) {
      const currentUserData = {
        nombre: user.nombre,
        balance: usersData[code].balance || 0,
        paidBalance: usersData[code].paidBalance || 0,
        earnings: usersData[code].earnings || 0,
        referralCount: usersData[code].referralCount || 0,
      }
      setUserData(currentUserData)
      localStorage.setItem("currentDashboardCode", code)
    } else {
      setUserData({
        nombre: "",
        balance: 0,
        paidBalance: 0,
        earnings: 0,
        referralCount: 0,
      })
      alert("Usuario no encontrado")
    }
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    loadUserData(referralCode)
  }

  useEffect(() => {
    const savedCode = localStorage.getItem("currentDashboardCode")
    if (savedCode) {
      setReferralCode(savedCode)
      loadUserData(savedCode)
    }
  }, [loadUserData])

  return (
    <Card className="bg-[#1f1f1f] mb-8">
      <CardHeader>
        <CardTitle className="text-[#00ffcc]">Dashboard de Usuario</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="mb-4">
          <div className="flex space-x-2">
            <Input
              value={referralCode}
              onChange={(e) => setReferralCode(e.target.value)}
              placeholder="Ingrese código de referido"
            />
            <Button type="submit" className="bg-[#00ffcc] text-black hover:bg-[#00e6b8]">
              Cargar Datos
            </Button>
          </div>
        </form>
        {userData.nombre && (
          <div className="mb-4">
            <h2 className="text-xl font-bold text-[#00ffcc]">Bienvenido, {userData.nombre}</h2>
          </div>
        )}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader>
              <CardTitle>Saldo Acumulado</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{userData.balance} Tokens</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Saldo Pagado</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{userData.paidBalance} Tokens</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Ganancias</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{userData.earnings.toFixed(2)} Tokens</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Usuarios Referidos</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{userData.referralCount}</p>
            </CardContent>
          </Card>
        </div>
      </CardContent>
    </Card>
  )
}


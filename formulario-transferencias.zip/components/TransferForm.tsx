"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectGroup } from "@/components/ui/select"

const cities = [
  "Bogotá",
  "Medellín",
  "Cali",
  "Barranquilla",
  "Cartagena",
  "Bucaramanga",
  "Santa Marta",
  "Pereira",
  "Manizales",
  "Armenia",
  "Dosquebradas",
  "Barcelona",
  "Pijao",
  "Circasia",
  "Cartago",
  "Zarzal",
  "Quimbaya",
  "Pueblo Tapao",
  "Tebaida",
  "Calarca",
]

const EMPRESA_CODE = "ATQDFJ"

export default function TransferForm() {
  const [formData, setFormData] = useState({
    ciudad: "",
    usuario: "",
    tokens: "",
    detalles: "",
    codigoReferido: "",
  })

  const updateUserData = (referralCode: string, amount: number) => {
    const usersData = JSON.parse(localStorage.getItem("usersData") || "{}")
    if (!usersData[referralCode]) {
      usersData[referralCode] = { balance: 0, paidBalance: 0, earnings: 0, referralCount: 0 }
    }
    usersData[referralCode].balance += amount
    usersData[referralCode].earnings += amount * 0.1 // Asumimos una comisión del 10%
    localStorage.setItem("usersData", JSON.stringify(usersData))

    // Actualizar el dashboard si el código de referido coincide con el código actual
    window.dispatchEvent(new CustomEvent("dashboardUpdate", { detail: { referralCode } }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const estado = ["Aprobado", "Pendiente", "Rechazado"][Math.floor(Math.random() * 3)]
    const fecha = new Date().toLocaleString()
    const codigoReferido = formData.codigoReferido || EMPRESA_CODE // Usa el código de la empresa si no se proporciona uno
    const newTransfer = { ...formData, estado, fecha, tokens: Number(formData.tokens), codigoReferido }

    const transfers = JSON.parse(localStorage.getItem("transfers") || "[]")
    transfers.push(newTransfer)
    localStorage.setItem("transfers", JSON.stringify(transfers))

    // Actualizar datos del usuario que refirió
    updateUserData(codigoReferido, Number(formData.tokens))

    setFormData({ ciudad: "", usuario: "", tokens: "", detalles: "", codigoReferido: "" })
    window.dispatchEvent(new Event("storage"))
    alert("Transferencia registrada con éxito")
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.id]: e.target.value })
  }

  return (
    <Card className="bg-[#1f1f1f] mb-8">
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="ciudad">Ciudad</Label>
            <Select onValueChange={(value) => setFormData({ ...formData, ciudad: value })}>
              <SelectTrigger className="w-full bg-white text-black">
                <SelectValue placeholder="Selecciona una ciudad" />
              </SelectTrigger>
              <SelectContent className="bg-white text-black max-h-[300px] overflow-y-auto">
                <SelectGroup>
                  {cities.map((city) => (
                    <SelectItem key={city} value={city}>
                      {city}
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="usuario">Usuario</Label>
            <Input
              id="usuario"
              placeholder="Nombre del usuario"
              value={formData.usuario}
              onChange={handleChange}
              required
            />
          </div>
          <div>
            <Label htmlFor="tokens">Cantidad de Tokens</Label>
            <Input
              id="tokens"
              type="number"
              placeholder="Cantidad de tokens"
              value={formData.tokens}
              onChange={handleChange}
              required
            />
          </div>
          <div>
            <Label htmlFor="codigoReferido">Código de Referido</Label>
            <Input
              id="codigoReferido"
              placeholder="Código de referido (opcional)"
              value={formData.codigoReferido}
              onChange={handleChange}
            />
          </div>
          <div>
            <Label htmlFor="detalles">Detalles</Label>
            <Textarea
              id="detalles"
              placeholder="Detalles adicionales"
              value={formData.detalles}
              onChange={handleChange}
            />
          </div>
          <Button type="submit" className="bg-[#00ffcc] text-black hover:bg-[#00e6b8]">
            Enviar
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}


import ReferralLinkGenerator from "@/components/ReferralLinkGenerator"

export default function ReferralLinkPage() {
  return <ReferralLinkGenerator />
}


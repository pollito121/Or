"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import * as XLSX from "xlsx"

interface Transfer {
  fecha: string
  ciudad: string
  usuario: string
  tokens: number
  detalles: string
  estado: string
  codigoReferido: string
}

interface Referral {
  code: string
  referrer: string
  date: string
}

export default function TransferHistory() {
  const [transfers, setTransfers] = useState<Transfer[]>([])
  const [referrals, setReferrals] = useState<Referral[]>([])
  const [showReferrals, setShowReferrals] = useState(false)

  useEffect(() => {
    const loadData = () => {
      const storedTransfers = JSON.parse(localStorage.getItem("transfers") || "[]")
      const storedReferrals = JSON.parse(localStorage.getItem("referrals") || "[]")
      setTransfers(storedTransfers)
      setReferrals(storedReferrals)
    }

    loadData()
    window.addEventListener("storage", loadData)
    return () => window.removeEventListener("storage", loadData)
  }, [])

  const showDetails = (details: string) => {
    alert(`Detalles de la transferencia:\n\n${details}`)
  }

  const changeTransferStatus = (index: number, newStatus: string) => {
    const updatedTransfers = [...transfers]
    updatedTransfers[index].estado = newStatus
    setTransfers(updatedTransfers)
    localStorage.setItem("transfers", JSON.stringify(updatedTransfers))
  }

  const downloadExcel = () => {
    const data = showReferrals ? referrals : transfers
    const worksheet = XLSX.utils.json_to_sheet(data)
    const workbook = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(workbook, worksheet, showReferrals ? "Referrals" : "Transfers")
    XLSX.writeFile(workbook, showReferrals ? "referidos.xlsx" : "transferencias.xlsx")
  }

  return (
    <Card className="bg-[#1f1f1f]">
      <CardHeader>
        <CardTitle className="text-[#00ffcc]">Historial</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex justify-between items-center mb-4">
          <div>
            <Button
              onClick={() => setShowReferrals(false)}
              className={`mr-2 ${!showReferrals ? "bg-[#00ffcc] text-black" : "bg-gray-600"}`}
            >
              Transferencias
            </Button>
            <Button
              onClick={() => setShowReferrals(true)}
              className={`${showReferrals ? "bg-[#00ffcc] text-black" : "bg-gray-600"}`}
            >
              Referidos
            </Button>
          </div>
          <Button onClick={downloadExcel} className="bg-[#00ffcc] text-black hover:bg-[#00e6b8]">
            Descargar Excel
          </Button>
        </div>
        <div className="overflow-x-auto">
          {showReferrals ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Fecha</TableHead>
                  <TableHead>Código de Referido</TableHead>
                  <TableHead>Referidor</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {referrals.map((referral, index) => (
                  <TableRow key={index}>
                    <TableCell>{new Date(referral.date).toLocaleString()}</TableCell>
                    <TableCell>{referral.code}</TableCell>
                    <TableCell>{referral.referrer}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Fecha</TableHead>
                  <TableHead>Ciudad</TableHead>
                  <TableHead>Usuario</TableHead>
                  <TableHead>Tokens</TableHead>
                  <TableHead>Total en USD</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Código Referido</TableHead>
                  <TableHead>Detalles</TableHead>
                  <TableHead>Acción</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transfers.map((transfer, index) => (
                  <TableRow key={index}>
                    <TableCell>{transfer.fecha}</TableCell>
                    <TableCell>{transfer.ciudad}</TableCell>
                    <TableCell>{transfer.usuario}</TableCell>
                    <TableCell>{transfer.tokens}</TableCell>
                    <TableCell>${(transfer.tokens * 100).toFixed(2)}</TableCell>
                    <TableCell>
                      <Select value={transfer.estado} onValueChange={(value) => changeTransferStatus(index, value)}>
                        <SelectTrigger className="w-[120px]">
                          <SelectValue placeholder={transfer.estado} />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Pendiente">Pendiente</SelectItem>
                          <SelectItem value="Aprobado">Aprobado</SelectItem>
                          <SelectItem value="Rechazado">Rechazado</SelectItem>
                          <SelectItem value="Pagado">Pagado</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell>{transfer.codigoReferido || "N/A"}</TableCell>
                    <TableCell>
                      <span
                        className="ver-detalles cursor-pointer text-[#00ffcc]"
                        onClick={() => showDetails(transfer.detalles)}
                      >
                        Ver Detalles
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


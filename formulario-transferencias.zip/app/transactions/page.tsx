import TransferForm from "@/components/TransferForm"

export default function TransactionsPage() {
  return <TransferForm />
}


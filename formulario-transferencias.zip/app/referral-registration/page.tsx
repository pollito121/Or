import { Suspense } from "react"
import ReferralRegistration from "@/components/ReferralRegistration"

export default function ReferralRegistrationPage() {
  return (
    <Suspense fallback={<div>Cargando...</div>}>
      <ReferralRegistration />
    </Suspense>
  )
}


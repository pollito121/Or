"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { LayoutDashboard, UserPlus, LinkIcon, History, CreditCard } from "lucide-react"

const navItems = [
  {
    href: "/",
    text: "Dashboard",
    icon: LayoutDashboard,
  },
  {
    href: "/referral-registration",
    text: "Registro",
    icon: UserPlus,
  },
  {
    href: "/referral-link",
    text: "Enlaces",
    icon: LinkIcon,
  },
  {
    href: "/history",
    text: "Historial",
    icon: History,
  },
  {
    href: "/transactions",
    text: "Transacciones",
    icon: CreditCard,
  },
]

export default function Navbar() {
  const pathname = usePathname()

  return (
    <nav className="fixed bottom-0 left-0 w-full bg-black shadow-lg border-t-2 border-[#1abc9c]">
      <div className="flex justify-around items-center py-2">
        {navItems.map((item, index) => {
          const Icon = item.icon
          return (
            <Link
              key={index}
              href={item.href}
              className={`flex flex-col items-center ${pathname === item.href ? "text-[#00ffcc]" : "text-[#ecf0f1]"}`}
            >
              <Icon className="w-6 h-6" />
              <span className="text-xs mt-1">{item.text}</span>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}


import TransferHistory from "@/components/TransferHistory"

export default function HistoryPage() {
  return <TransferHistory />
}


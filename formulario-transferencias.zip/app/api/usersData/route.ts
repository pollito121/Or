import { kv } from "@vercel/kv"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const usersData = (await kv.get("usersData")) || {}
    return NextResponse.json(usersData)
  } catch (error) {
    console.error("Error fetching usersData:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const { code, data } = await request.json()
    const usersData = (await kv.get("usersData")) || {}
    usersData[code] = data
    await kv.set("usersData", usersData)
    return NextResponse.json(usersData[code], { status: 201 })
  } catch (error) {
    console.error("Error updating usersData:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}


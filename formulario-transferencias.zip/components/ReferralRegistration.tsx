"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

interface UserData {
  id: string
  nombre: string
  apellidos: string
  telefono: string
  correo: string
  codigoReferidor: string
  codigoPropio: string
}

const EMPRESA_CODE = "ATQDFJ"
const EMPRESA_NAME = "Orbital X"
const WORLDCOIN_URL = `https://worldcoin.org/mini-app?app_id=${process.env.NEXT_PUBLIC_APP_ID}&path=`

export default function ReferralRegistration() {
  const searchParams = useSearchParams()
  const [userData, setUserData] = useState<UserData>({
    id: "",
    nombre: "",
    apellidos: "",
    telefono: "",
    correo: "",
    codigoReferidor: "",
    codigoPropio: "",
  })

  useEffect(() => {
    const initializeUsersData = async () => {
      try {
        const response = await fetch("/api/usersData")
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`)
        }
        const usersData = await response.json()
        if (!usersData[EMPRESA_CODE]) {
          await fetch("/api/usersData", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              code: EMPRESA_CODE,
              data: {
                balance: 0,
                paidBalance: 0,
                earnings: 0,
                referralCount: 0,
              },
            }),
          })
        }
      } catch (error) {
        console.error("Error initializing users data:", error)
      }
    }

    initializeUsersData()

    const refCode = searchParams.get("ref")
    if (refCode) {
      setUserData((prevState) => ({ ...prevState, codigoReferidor: refCode }))
    }
  }, [searchParams])

  const generateUniqueCode = () => {
    return Math.random().toString(36).substring(2, 8).toUpperCase()
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUserData({ ...userData, [e.target.id]: e.target.value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const newUser = {
      ...userData,
      id: Date.now().toString(),
      codigoPropio: generateUniqueCode(),
    }

    // Guardar el nuevo usuario
    await fetch("/api/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newUser),
    })

    // Actualizar los datos del referidor
    const codigoReferidor = userData.codigoReferidor || EMPRESA_CODE
    const usersDataResponse = await fetch("/api/usersData")
    const usersData = await usersDataResponse.json()
    if (usersData[codigoReferidor]) {
      usersData[codigoReferidor].referralCount += 1
      await fetch("/api/usersData", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code: codigoReferidor,
          data: usersData[codigoReferidor],
        }),
      })
    }

    // Crear entrada en usersData para el nuevo usuario
    await fetch("/api/usersData", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        code: newUser.codigoPropio,
        data: {
          balance: 0,
          paidBalance: 0,
          earnings: 0,
          referralCount: 0,
        },
      }),
    })

    // Redirigir al usuario a Worldcoin
    window.location.href = WORLDCOIN_URL
  }

  return (
    <Card className="bg-[#1f1f1f] mb-8">
      <CardHeader>
        <CardTitle className="text-[#00ffcc]">Registro de Usuario</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="nombre">Nombre</Label>
            <Input
              id="nombre"
              value={userData.nombre}
              onChange={handleChange}
              placeholder="Ingrese su nombre"
              required
            />
          </div>
          <div>
            <Label htmlFor="apellidos">Apellidos</Label>
            <Input
              id="apellidos"
              value={userData.apellidos}
              onChange={handleChange}
              placeholder="Ingrese sus apellidos"
              required
            />
          </div>
          <div>
            <Label htmlFor="telefono">Teléfono</Label>
            <Input
              id="telefono"
              value={userData.telefono}
              onChange={handleChange}
              placeholder="Ingrese su teléfono"
              required
            />
          </div>
          <div>
            <Label htmlFor="correo">Correo Electrónico</Label>
            <Input
              id="correo"
              type="email"
              value={userData.correo}
              onChange={handleChange}
              placeholder="Ingrese su correo electrónico"
              required
            />
          </div>
          <div>
            <Label htmlFor="codigoReferidor">Código de Referido</Label>
            <Input
              id="codigoReferidor"
              value={userData.codigoReferidor}
              onChange={handleChange}
              placeholder="Código de referido"
              readOnly={!!searchParams.get("ref")}
            />
          </div>
          <Button type="submit" className="bg-[#00ffcc] text-black hover:bg-[#00e6b8]">
            Registrar Usuario
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

